class InertiaVersionConflictException(Exception):
    pass
